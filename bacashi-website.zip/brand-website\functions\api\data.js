/**
 * CAFELE 数据 API - Cloudflare Pages Function
 *
 * 为静态网站提供跨设备数据同步能力。
 * 通过代理腾讯云 COS API 实现数据读写（无需客户端密钥）。
 *
 * 环境变量（在 Cloudflare Pages 后台设置）：
 * - COS_BUCKET: COS 存储桶名称
 * - COS_REGION: COS 地域
 * - COS_SECRET_ID: COS 密钥 ID
 * - COS_SECRET_KEY: COS 密钥 Key
 * - COS_DATA_KEY: COS 中数据文件的路径（选填，默认 website-data/backup.json）
 */

// COS API 签名工具
function cosSign(method, path, headers, params, secrets) {
    const { secretId, secretKey } = secrets;

    // 排序参数
    let allParams = { ...params };
    const allHeaders = {
        host: `${secrets.bucket}.cos.${secrets.region}.myqcloud.com`,
        'content-type': 'application/json',
        ...headers,
    };

    // 构建签名
    const httpString = method + '\n' + path + '\n' + buildQueryString(allParams) + '\n' + buildHeaders(allHeaders) + '\n';

    const signAlgorithm = 'sha256';
    const signTime = `${Math.floor(Date.now() / 1000)};7200`; // 2小时有效期
    const keyTime = signTime;
    const service = 'cos';

    const sha256 = async (str) => {
        const enc = new TextEncoder().encode(str);
        const hash = await crypto.subtle.digest('SHA-256', enc);
        return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
    };

    const hmacSha256 = async (key, msg) => {
        const encKey = new TextEncoder().encode(key);
        const encMsg = new TextEncoder().encode(msg);
        const cryptoKey = await crypto.subtle.importKey('raw', encKey, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
        const sig = await crypto.subtle.sign('HMAC', cryptoKey, encMsg);
        return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, '0')).join('');
    };

    const signKey = (keyTime) => {
        const parts = keyTime.split(';');
        const startKey = `HMAC-SHA256=Credential=${secretId}`;
        return startKey;
    };

    // 简化版：直接使用 COS 预签名 URL 方式
    return { signTime, keyTime };
}

// 生成 COS 预签名 URL
async function generateCosUrl(method, path, secrets) {
    const { bucket, region, secretId, secretKey, dataKey } = secrets;
    const bucketHost = `${bucket}.cos.${region}.myqcloud.com`;
    const url = `https://${bucketHost}${path}`;

    const now = Math.floor(Date.now() / 1000);
    const expires = now + 3600; // 1小时

    // 简单的 COS 签名（用于请求）
    const signStr = await buildAuthorization(method, path, secrets, now, expires);

    return {
        url,
        authorization: signStr,
        date: new Date(now * 1000).toUTCString(),
    };
}

// 构建 COS Authorization 头
async function buildAuthorization(method, path, secrets, startTime, endTime) {
    const { secretId, secretKey, bucket, region } = secrets;
    const keyTime = `${startTime};${endTime}`;

    // 签名算法
    const sha256Hex = async (data) => {
        const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(data));
        return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
    };

    const hmacSha256 = async (key, data) => {
        const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(key),
            { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
        const sig = await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(data));
        return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, '0')).join('');
    };

    const service = 'cos';
    const httpString = method.toLowerCase() + '\n' + path + '\n\nhost=' + bucket + '.cos.' + region + '.myqcloud.com\n';
    const sha256edHttpString = await sha256Hex(httpString);
    const stringToSign = `sha256\n${keyTime}\n${sha256edHttpString}\n`;

    const signKey = await hmacSha256(secretKey, keyTime);
    const signature = await hmacSha256(signKey, stringToSign);

    return [
        `q-sign-algorithm=sha256`,
        `q-ak=${secretId}`,
        `q-sign-time=${keyTime}`,
        `q-key-time=${keyTime}`,
        `q-header-list=host`,
        `q-url-param-list=`,
        `q-signature=${signature}`,
    ].join('&');
}

function buildQueryString(params) {
    return Object.entries(params)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
        .join('&');
}

function buildHeaders(headers) {
    return Object.entries(headers)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([k, v]) => `${k.toLowerCase()}=${encodeURIComponent(v)}\n`)
        .join('');
}

async function getCosData(env) {
    const bucket = env.COS_BUCKET || 'bacashi-1300000000-1412313617';
    const region = env.COS_REGION || 'ap-shanghai';
    const dataKey = env.COS_DATA_KEY || 'website-data/backup.json';

    const url = `https://${bucket}.cos.${region}.myqcloud.com/${dataKey}?t=${Date.now()}`;
    const resp = await fetch(url);

    if (resp.status === 404) {
        return null;
    }
    if (!resp.ok) {
        throw new Error(`COS fetch failed: ${resp.status}`);
    }
    return await resp.json();
}

async function putCosData(data, env) {
    const bucket = env.COS_BUCKET || 'bacashi-1300000000-1412313617';
    const region = env.COS_REGION || 'ap-shanghai';
    const secretId = env.COS_SECRET_ID;
    const secretKey = env.COS_SECRET_KEY;
    const dataKey = env.COS_DATA_KEY || 'website-data/backup.json';

    if (!secretId || !secretKey) {
        throw new Error('COS_SECRET_ID 或 COS_SECRET_KEY 未配置');
    }

    const path = '/' + dataKey;
    const body = JSON.stringify(data);
    const now = Math.floor(Date.now() / 1000);
    const expires = now + 3600;

    // 构建签名
    const keyTime = `${now};${expires}`;
    const sha256Hex = async (data) => {
        const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(data));
        return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
    };
    const hmacSha256 = async (key, data) => {
        const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(key),
            { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
        const sig = await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(data));
        return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, '0')).join('');
    };

    const headers = `host=${bucket}.cos.${region}.myqcloud.com`;
    const uriPath = path;
    const httpString = 'put\n' + uriPath + '\n\n' + headers + '\n';
    const sha256edHttpString = await sha256Hex(httpString);
    const stringToSign = 'sha256\n' + keyTime + '\n' + sha256edHttpString + '\n';
    const signKey = await hmacSha256(secretKey, keyTime);
    const signature = await hmacSha256(signKey, stringToSign);

    const authorization = [
        `q-sign-algorithm=sha256`,
        `q-ak=${secretId}`,
        `q-sign-time=${keyTime}`,
        `q-key-time=${keyTime}`,
        `q-header-list=host`,
        `q-url-param-list=`,
        `q-signature=${signature}`,
    ].join('&');

    const url = `https://${bucket}.cos.${region}.myqcloud.com/${dataKey}`;
    const resp = await fetch(url, {
        method: 'PUT',
        headers: {
            'Authorization': authorization,
            'Content-Type': 'application/json',
        },
        body: body,
    });

    if (!resp.ok) {
        const txt = await resp.text();
        throw new Error(`COS upload failed (${resp.status}): ${txt}`);
    }

    return true;
}

// Cloudflare Pages Function 入口
export async function onRequest(context) {
    const { request, env } = context;
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // CORS 头
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    };

    // 处理 OPTIONS 预检请求
    if (method === 'OPTIONS') {
        return new Response(null, { status: 204, headers: corsHeaders });
    }

    try {
        // GET /api/data - 读取所有数据
        if (method === 'GET' && path === '/api/data') {
            const data = await getCosData(env);
            return new Response(JSON.stringify(data || { brandData: null, bacashiData: null }), {
                headers: { 'Content-Type': 'application/json', ...corsHeaders },
            });
        }

        // POST /api/data - 保存数据
        if (method === 'POST' && path === '/api/data') {
            const body = await request.json();
            // 读取现有数据，合并后写入
            let existing = {};
            try {
                existing = await getCosData(env) || {};
            } catch (e) { /* 忽略 */ }

            const merged = { ...existing, ...body, updatedAt: new Date().toISOString() };
            await putCosData(merged, env);
            return new Response(JSON.stringify({ success: true, updatedAt: merged.updatedAt }), {
                headers: { 'Content-Type': 'application/json', ...corsHeaders },
            });
        }

        // POST /api/upload - 上传图片（base64 方式）
        if (method === 'POST' && path === '/api/upload') {
            const { secretId, secretKey } = env;
            if (!secretId || !secretKey) {
                return new Response(JSON.stringify({ error: 'COS 未配置' }), {
                    status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders },
                });
            }

            const formData = await request.formData();
            const file = formData.get('image');
            if (!file) {
                return new Response(JSON.stringify({ error: '没有上传文件' }), {
                    status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders },
                });
            }

            const bucket = env.COS_BUCKET || 'bacashi-1300000000-1412313617';
            const region = env.COS_REGION || 'ap-shanghai';
            const timestamp = Date.now();
            const randomStr = Math.random().toString(36).substring(2, 8);
            const ext = file.name.split('.').pop() || 'jpg';
            const filename = `products/${timestamp}_${randomStr}.${ext}`;
            const cosPath = '/' + filename;

            const buffer = await file.arrayBuffer();
            const now = Math.floor(Date.now() / 1000);
            const expires = now + 3600;
            const keyTime = `${now};${expires}`;

            const sha256Hex = async (data) => {
                const hash = await crypto.subtle.digest('SHA-256', data);
                return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
            };
            const hmacSha256 = async (key, data) => {
                const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(key),
                    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
                const sig = await crypto.subtle.sign('HMAC', k, data);
                return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, '0')).join('');
            };

            const headers = `host=${bucket}.cos.${region}.myqcloud.com`;
            const httpString = 'put\n' + cosPath + '\n\n' + headers + '\n';
            const shaBody = await sha256Hex(buffer);
            const stringToSign = 'sha256\n' + keyTime + '\n' + (await sha256Hex(httpString)) + '\n';
            const signKey = await hmacSha256(env.COS_SECRET_KEY, keyTime);
            const signature = await hmacSha256(signKey, stringToSign);

            const authorization = [
                `q-sign-algorithm=sha256`,
                `q-ak=${env.COS_SECRET_ID}`,
                `q-sign-time=${keyTime}`,
                `q-key-time=${keyTime}`,
                `q-header-list=host`,
                `q-url-param-list=`,
                `q-signature=${signature}`,
            ].join('&');

            const uploadUrl = `https://${bucket}.cos.${region}.myqcloud.com/${filename}`;
            const resp = await fetch(uploadUrl, {
                method: 'PUT',
                headers: {
                    'Authorization': authorization,
                    'Content-Type': file.type || 'application/octet-stream',
                },
                body: buffer,
            });

            if (!resp.ok) {
                const txt = await resp.text();
                throw new Error(`Upload failed (${resp.status}): ${txt}`);
            }

            return new Response(JSON.stringify({ url: uploadUrl }), {
                headers: { 'Content-Type': 'application/json', ...corsHeaders },
            });
        }

        // 不存在路由
        return new Response(JSON.stringify({ error: 'Not found' }), {
            status: 404, headers: { 'Content-Type': 'application/json', ...corsHeaders },
        });

    } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), {
            status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders },
        });
    }
}
